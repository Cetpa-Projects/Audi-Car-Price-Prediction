# Audi-Car-Price-Prediction
Project Overview This project predicts the **price of Audi cars** based on various features such as model, year, mileage, fuel type, and engine specifications.  It is a **regression problem**, where the goal is to estimate the continuous value of car prices. 
## 🎯 Objective
To build a machine learning model that can accurately predict the **resale price of Audi cars** using historical data.

---

## 📊 Dataset Information

The dataset contains information about Audi cars, including:

- Model  
- Year  
- Price  
- Transmission  
- Mileage  
- Fuel Type  
- Tax  
- MPG (Miles Per Gallon)  
- Engine Size  

### Sample Data:

| Model | Year | Price | Transmission | Mileage | Fuel Type | Tax | MPG | Engine Size |
|------|------|------|-------------|--------|-----------|-----|-----|------------|
| A1   | 2017 | 12500 | Manual      | 15735  | Petrol    | 150 | 55.4 | 1.4 |
| A6   | 2016 | 16500 | Automatic   | 36203  | Diesel    | 20  | 64.2 | 2.0 |

---

## 🧠 Features Used

- Model  
- Year  
- Transmission  
- Mileage  
- Fuel Type  
- Tax  
- MPG  
- Engine Size  

---

## ⚙️ Project Workflow

1. Data Cleaning  
2. Exploratory Data Analysis (EDA)  
3. Feature Encoding (Categorical → Numerical)  
4. Model Training  
5. Model Evaluation  

---

## 🤖 Model Used

- Random Forest Regressor  

---

## 📈 Evaluation Metrics

- R² Score  
- Mean Absolute Error (MAE)  
- Mean Squared Error (MSE)  

---

## 🛠️ Tech Stack

- Python  
- Pandas  
- NumPy  
- Matplotlib / Seaborn  
- Scikit-learn  

---

## 🚀 How to Run

```bash
git clone https://github.com/your-username/audi-price-prediction.git
cd audi-price-prediction
pip install -r requirements.txt
python app.py
